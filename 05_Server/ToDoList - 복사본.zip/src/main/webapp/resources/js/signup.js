console.log('signup.js loaded');
