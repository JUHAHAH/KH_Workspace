document.querySelector('#btn').addEventListener('click', () => {
  alert('클릭함');
});
